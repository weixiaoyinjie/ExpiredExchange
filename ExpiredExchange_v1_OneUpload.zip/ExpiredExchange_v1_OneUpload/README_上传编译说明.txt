过期商品扫码 + AI识别 + 换货商管理 APK v1.0
====================================
【不用 Supabase】所有商品、换货商、换货状态保存在本机 SQLite。

功能
- ML Kit 相机扫码，支持 EAN13、UPC 等常见条形码；条形码也可以手动输入
- Open Food Facts 在线查询商品名称、品牌和规格，本地缓存已查询商品
- 拍照 / 相册：ML Kit 本地识别包装文字和日期；在设置里填写 OpenAI Key 后可做 AI 包装识别及自动分类
- 商品名称、品牌、规格、类别、过期数量、过期日期录入
- 自动按类别与品牌展示待分配商品，勾选批量剪切到指定经销商
- 经销商可自行新增、改名；每个商品带已换货复选框
- 记录修改、撤回待分配池、删除
- JSON 本地备份恢复（含照片）

【推荐使用新的、空的 GitHub 仓库；不要把 ZIP 作为单个文件上传】
方法 A：GitHub 网页一键上传全部项目文件
1. 创建 GitHub 新仓库，如 ExpiredExchange，Visibility 可以设为 Private。
2. 下载并解压本 ZIP，进入解压出的目录。
3. 打开仓库的 Add file -> Upload files 页面，拖入解压后的全部文件及文件夹（包含隐藏目录 .github）。
4. Commit changes 到 main 分支。
5. GitHub 顶部 Actions -> Build Android APK -> 点击对应运行，等待绿色 ✓。
6. 进入成功的运行页面底部 Artifacts，下载 ExpiredExchange-v1-APK.zip。
7. 解压这个产物 ZIP，里面的 app-debug.apk 安装到手机。

方法 B：Android Studio 打开项目，使用 Gradle 8.11.1 / JDK17 编译 :app:assembleDebug。

【注意】
- 这里提供的是源码 ZIP 和 GitHub Actions 自动编译方案，不是直接编译好的 APK。
- 需要 GitHub Actions 的 Ubuntu 构建机在线下载 Android SDK 和 Gradle 依赖。
- Android 8.0+；手机安装未知来源应用需要手动授权。
- 安装后「设置」->「OpenAI 智能识别」内输入自己已有的 API Key；切勿把 Key 粘贴到 GitHub 源代码。
- ML Kit 扫码/文字识别支持离线；Open Food Facts 和 OpenAI 识别需要联网。
- 过期日期通常不在 EAN 条形码中；OCR 读取包装日期只作为建议，要人工核对。
- OCR 只能自动识别包含明确 EXP/VTO/VENC 等标签并带日月年的日期；其他情况手动填写。
- 请定期使用“导出备份 JSON”，卸载应用通常会删除手机本地记录。
- 这版暂未在真实设备或远程 GitHub Actions 进行实际构建测试；若 Actions 报错，请提供失败日志。

源码路径：app/src/main/java/com/expiredexchange/app/
工作流文件：.github/workflows/build-apk.yml

方法 C（你以前习惯的：直接上传 1 个 ZIP 到 GitHub）
1. 在 GitHub 仓库中新建 .github/workflows/build-apk.yml 文件。
2. 将另外提供的 GitHub_单ZIP编译工作流.yml.txt 内容全部复制粘贴进去并提交。这一步只做一次。
3. 把 ExpiredExchange_v1_OneUpload.zip 直接上传到仓库根目录，名称保持不变，不用解压。
4. Actions 会在 push 后自动编译，或手动点击 Run workflow。
5. Actions -> 本次运行 -> Artifacts -> 下载 ExpiredExchange-v1-APK.zip -> 解压获得 app-debug.apk。
