package com.expiredexchange.app;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;

final class Streams {
    static byte[] readAll(InputStream input) throws java.io.IOException {
        ByteArrayOutputStream output=new ByteArrayOutputStream();
        byte[] buffer=new byte[8192];
        int bytes;
        while((bytes=input.read(buffer))!=-1){output.write(buffer,0,bytes);if(output.size()>55_000_000)throw new java.io.IOException("输入内容过大");}
        return output.toByteArray();
    }
    private Streams(){}
}
