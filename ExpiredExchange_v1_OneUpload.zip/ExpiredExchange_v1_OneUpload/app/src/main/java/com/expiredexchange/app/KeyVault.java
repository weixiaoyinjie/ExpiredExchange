package com.expiredexchange.app;

import android.content.Context;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/** API Key is device-local and encrypted with a non-exportable Android Keystore key. */
final class KeyVault {
    private static final String ALIAS="ExpiredExchange_OpenAI_v1";
    static void save(Context context,String value) throws Exception {
        KeyStore ks=KeyStore.getInstance("AndroidKeyStore");ks.load(null);
        if(!ks.containsAlias(ALIAS)){
            KeyGenerator gen=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore");
            gen.init(new KeyGenParameterSpec.Builder(ALIAS,KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build());
            gen.generateKey();
        }
        SecretKey key=(SecretKey)ks.getKey(ALIAS,null);
        Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");cipher.init(Cipher.ENCRYPT_MODE,key);
        byte[] bytes=cipher.doFinal(value.getBytes(StandardCharsets.UTF_8));
        context.getSharedPreferences("secure",Context.MODE_PRIVATE).edit()
            .putString("key",Base64.encodeToString(bytes,Base64.NO_WRAP))
            .putString("nonce",Base64.encodeToString(cipher.getIV(),Base64.NO_WRAP)).apply();
    }
    static String read(Context context) {
        try {
            String text=context.getSharedPreferences("secure",Context.MODE_PRIVATE).getString("key","");
            String iv=context.getSharedPreferences("secure",Context.MODE_PRIVATE).getString("nonce","");
            if(text.isEmpty()||iv.isEmpty())return "";
            KeyStore ks=KeyStore.getInstance("AndroidKeyStore");ks.load(null);
            SecretKey key=(SecretKey)ks.getKey(ALIAS,null);
            if(key==null)return "";
            Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.DECRYPT_MODE,key,new GCMParameterSpec(128,Base64.decode(iv,Base64.NO_WRAP)));
            return new String(cipher.doFinal(Base64.decode(text,Base64.NO_WRAP)),StandardCharsets.UTF_8);
        }catch(Exception ignored){return "";}
    }
    static void clear(Context context){context.getSharedPreferences("secure",Context.MODE_PRIVATE).edit().clear().apply();}
    private KeyVault(){}
}
