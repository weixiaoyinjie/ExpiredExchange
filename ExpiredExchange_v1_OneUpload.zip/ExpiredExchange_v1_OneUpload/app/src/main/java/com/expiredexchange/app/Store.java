package com.expiredexchange.app;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Base64;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.File;
import java.io.FileOutputStream;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;

public class Store extends SQLiteOpenHelper {
    public static class Item {
        public long id, dealerId;
        public String barcode="", name="", brand="", category="其他", size="", expiry="", photo="";
        public int quantity=1, exchanged=0;
    }
    public static class Dealer {
        public long id;
        public String name;
        Dealer(long i, String n) { id=i; name=n; }
    }
    Store(Context context) { super(context,"expired_exchange.db",null,1); }
    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE dealers (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL UNIQUE COLLATE NOCASE)");
        db.execSQL("CREATE TABLE items (id INTEGER PRIMARY KEY AUTOINCREMENT,barcode TEXT NOT NULL DEFAULT '',name TEXT NOT NULL,brand TEXT NOT NULL DEFAULT '',category TEXT NOT NULL DEFAULT '其他',size TEXT NOT NULL DEFAULT '',quantity INTEGER NOT NULL DEFAULT 1,expiry TEXT NOT NULL DEFAULT '',photo TEXT NOT NULL DEFAULT '',dealer_id INTEGER NOT NULL DEFAULT 0,exchanged INTEGER NOT NULL DEFAULT 0,created INTEGER NOT NULL)");
        db.execSQL("CREATE TABLE catalog (barcode TEXT PRIMARY KEY,name TEXT NOT NULL,brand TEXT NOT NULL,category TEXT NOT NULL,size TEXT NOT NULL)");
        db.execSQL("CREATE INDEX idx_item_dealer ON items(dealer_id,exchanged)");
    }
    @Override public void onUpgrade(SQLiteDatabase db,int oldVersion,int newVersion) { }
    private ContentValues values(Item a) {
        ContentValues v=new ContentValues();
        v.put("barcode",a.barcode);v.put("name",a.name);v.put("brand",a.brand);
        v.put("category",a.category);v.put("size",a.size);v.put("quantity",Math.max(1,a.quantity));
        v.put("expiry",a.expiry);v.put("photo",a.photo);v.put("dealer_id",a.dealerId);
        v.put("exchanged",a.exchanged);return v;
    }
    synchronized long save(Item a) {
        SQLiteDatabase db=getWritableDatabase(); ContentValues v=values(a);
        if(a.id>0) { db.update("items",v,"id=?",new String[]{String.valueOf(a.id)});return a.id; }
        v.put("created",System.currentTimeMillis());return db.insertOrThrow("items",null,v);
    }
    private Item item(Cursor c) {
        Item a=new Item();
        a.id=c.getLong(c.getColumnIndexOrThrow("id"));a.barcode=c.getString(c.getColumnIndexOrThrow("barcode"));
        a.name=c.getString(c.getColumnIndexOrThrow("name"));a.brand=c.getString(c.getColumnIndexOrThrow("brand"));
        a.category=c.getString(c.getColumnIndexOrThrow("category"));a.size=c.getString(c.getColumnIndexOrThrow("size"));
        a.quantity=c.getInt(c.getColumnIndexOrThrow("quantity"));a.expiry=c.getString(c.getColumnIndexOrThrow("expiry"));
        a.photo=c.getString(c.getColumnIndexOrThrow("photo"));a.dealerId=c.getLong(c.getColumnIndexOrThrow("dealer_id"));
        a.exchanged=c.getInt(c.getColumnIndexOrThrow("exchanged"));return a;
    }
    synchronized List<Item> list(long dealer) {
        List<Item> out=new ArrayList<>();
        try(Cursor c=getReadableDatabase().rawQuery("SELECT * FROM items WHERE dealer_id=? ORDER BY category COLLATE NOCASE,brand COLLATE NOCASE,name COLLATE NOCASE,id DESC", new String[]{String.valueOf(dealer)})) {
            while(c.moveToNext())out.add(item(c));
        }return out;
    }
    synchronized List<Item> all() {
        List<Item> out=new ArrayList<>();
        try(Cursor c=getReadableDatabase().rawQuery("SELECT * FROM items ORDER BY id",null)) {while(c.moveToNext())out.add(item(c));}
        return out;
    }
    synchronized int count(long dealer) {
        try(Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM items WHERE dealer_id=?",new String[]{String.valueOf(dealer)})) {return c.moveToFirst()?c.getInt(0):0;}
    }
    synchronized int finishedCount() {
        try(Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM items WHERE exchanged=1",null)) {return c.moveToFirst()?c.getInt(0):0;}
    }
    synchronized List<Dealer> dealers() {
        List<Dealer> out=new ArrayList<>();
        try(Cursor c=getReadableDatabase().rawQuery("SELECT id,name FROM dealers ORDER BY name COLLATE NOCASE",null)) {while(c.moveToNext())out.add(new Dealer(c.getLong(0),c.getString(1)));}
        return out;
    }
    synchronized boolean addDealer(String name) {
        ContentValues v=new ContentValues();v.put("name",name.trim());
        return getWritableDatabase().insertWithOnConflict("dealers",null,v,SQLiteDatabase.CONFLICT_IGNORE)>0;
    }
    synchronized void renameDealer(long id,String name) {
        ContentValues v=new ContentValues();v.put("name",name.trim());
        getWritableDatabase().update("dealers",v,"id=?",new String[]{""+id});
    }
    synchronized void move(List<Long> ids,long dealer) {
        SQLiteDatabase db=getWritableDatabase();db.beginTransaction();
        try {for(long id:ids){ContentValues v=new ContentValues();v.put("dealer_id",dealer);v.put("exchanged",0);db.update("items",v,"id=?",new String[]{""+id});}db.setTransactionSuccessful();}
        finally{db.endTransaction();}
    }
    synchronized void exchanged(long id,boolean yes) {
        ContentValues v=new ContentValues();v.put("exchanged",yes?1:0);
        getWritableDatabase().update("items",v,"id=?",new String[]{""+id});
    }
    synchronized void delete(long id) {getWritableDatabase().delete("items","id=?",new String[]{""+id});}
    synchronized void cache(String barcode,String name,String brand,String category,String size) {
        if(barcode.isEmpty())return;
        ContentValues v=new ContentValues();v.put("barcode",barcode);v.put("name",name);v.put("brand",brand);v.put("category",category);v.put("size",size);
        getWritableDatabase().insertWithOnConflict("catalog",null,v,SQLiteDatabase.CONFLICT_REPLACE);
    }
    synchronized Item cacheGet(String barcode) {
        try(Cursor c=getReadableDatabase().rawQuery("SELECT name,brand,category,size FROM catalog WHERE barcode=?",new String[]{barcode})) {
            if(!c.moveToFirst())return null;
            Item a=new Item();a.barcode=barcode;a.name=c.getString(0);a.brand=c.getString(1);a.category=c.getString(2);a.size=c.getString(3);return a;
        }
    }
    private JSONObject jsonItem(Item a, boolean includePhoto) throws Exception {
        JSONObject j=new JSONObject();j.put("id",a.id);j.put("barcode",a.barcode);j.put("name",a.name);j.put("brand",a.brand);
        j.put("category",a.category);j.put("size",a.size);j.put("quantity",a.quantity);j.put("expiry",a.expiry);
        j.put("dealer_id",a.dealerId);j.put("exchanged",a.exchanged);
        if(includePhoto&&!a.photo.isEmpty()) {
            File f=new File(a.photo);
            if(f.isFile() && f.length()<2_000_000)j.put("photo_base64",Base64.encodeToString(Files.readAllBytes(f.toPath()),Base64.NO_WRAP));
        }return j;
    }
    synchronized JSONObject backup() throws Exception {
        JSONObject root=new JSONObject();root.put("format","ExpiredExchangeBackupV1");
        JSONArray d=new JSONArray(),i=new JSONArray(),c=new JSONArray();
        for(Dealer a:dealers()){JSONObject j=new JSONObject();j.put("id",a.id);j.put("name",a.name);d.put(j);}
        for(Item a:all())i.put(jsonItem(a,true));
        try(Cursor q=getReadableDatabase().rawQuery("SELECT barcode,name,brand,category,size FROM catalog",null)) {
            while(q.moveToNext()){JSONObject j=new JSONObject();for(int x=0;x<5;x++)j.put(new String[]{"barcode","name","brand","category","size"}[x],q.getString(x));c.put(j);}
        }
        root.put("dealers",d);root.put("items",i);root.put("catalog",c);return root;
    }
    synchronized void restore(JSONObject root,Context context) throws Exception {
        if(!"ExpiredExchangeBackupV1".equals(root.optString("format")))throw new IllegalArgumentException("备份文件格式不正确");
        JSONArray dealers=root.getJSONArray("dealers"), items=root.getJSONArray("items"), catalog=root.optJSONArray("catalog");
        if(items.length()>100000)throw new IllegalArgumentException("记录数量超过限制");
        SQLiteDatabase db=getWritableDatabase();db.beginTransaction();
        try {
            db.delete("items",null,null);db.delete("dealers",null,null);db.delete("catalog",null,null);
            for(int k=0;k<dealers.length();k++){
                JSONObject j=dealers.getJSONObject(k);ContentValues v=new ContentValues();v.put("id",j.getLong("id"));v.put("name",j.getString("name"));db.insertOrThrow("dealers",null,v);
            }
            File dir=new File(context.getFilesDir(),"photos");dir.mkdirs();
            for(int k=0;k<items.length();k++){
                JSONObject j=items.getJSONObject(k);Item a=new Item();a.id=j.getLong("id");a.barcode=j.optString("barcode");
                a.name=j.optString("name");a.brand=j.optString("brand");a.category=j.optString("category","其他");
                a.size=j.optString("size");a.quantity=j.optInt("quantity",1);a.expiry=j.optString("expiry");
                a.dealerId=j.optLong("dealer_id");a.exchanged=j.optInt("exchanged");
                String photo=j.optString("photo_base64");
                if(!photo.isEmpty()) {byte[] bytes=Base64.decode(photo,Base64.DEFAULT);if(bytes.length<2_000_000){File f=File.createTempFile("restored_",".jpg",dir);try(FileOutputStream out=new FileOutputStream(f)){out.write(bytes);}a.photo=f.getAbsolutePath();}}
                ContentValues v=values(a);v.put("id",a.id);v.put("created",System.currentTimeMillis());db.insertOrThrow("items",null,v);
            }
            if(catalog!=null)for(int k=0;k<catalog.length();k++){
                JSONObject j=catalog.getJSONObject(k);ContentValues v=new ContentValues();
                for(String key:new String[]{"barcode","name","brand","category","size"})v.put(key,j.optString(key));
                db.insertWithOnConflict("catalog",null,v,SQLiteDatabase.CONFLICT_REPLACE);
            }
            db.setTransactionSuccessful();
        }finally{db.endTransaction();}
    }
}
