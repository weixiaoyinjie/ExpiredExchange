package com.expiredexchange.app;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.InputType;
import android.util.Base64;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.activity.ComponentActivity;
import androidx.core.content.FileProvider;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import org.json.JSONObject;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends ComponentActivity {
    private static final int BLUE=0xFF163B4A, TEAL=0xFF087E8B, BG=0xFFF4F7F8, INK=0xFF18303B, MUTED=0xFF6A7C86;
    private static final String[] CATEGORIES={"面包","酸奶","香肠","乳制品","饮料","零食","冷冻食品","罐头","日用品","其他"};
    private final ExecutorService io=Executors.newFixedThreadPool(2);
    private final Set<Long> chosen=new HashSet<>();
    private Store store;
    private LinearLayout page, holder;
    private EditText barcode,name,brand,size,quantity,expiry;
    private Spinner category;
    private TextView photoHint, networkHint;
    private Store.Item editing;
    private String pendingPhoto="";
    private File cameraFile;
    private int tab=0;
    private int dp(float x){return (int)(x*getResources().getDisplayMetrics().density+.5f);}
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);store=new Store(this);
        getWindow().setStatusBarColor(BLUE);getWindow().setNavigationBarColor(Color.WHITE);
        if(android.os.Build.VERSION.SDK_INT>=26)getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        openTab(0);
    }
    private GradientDrawable rounded(int color,float radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;}
    private LinearLayout column(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}
    private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    private TextView text(String s,int sp,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(TypedValue.COMPLEX_UNIT_SP,sp);t.setTextColor(color);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w<0?w:dp(w),h<0?h:dp(h));}
    private LinearLayout.LayoutParams gap(int vertical){LinearLayout.LayoutParams p=lp(-1,-2);p.topMargin=dp(vertical);return p;}
    private void pad(View v,int x,int y){v.setPadding(dp(x),dp(y),dp(x),dp(y));}
    private Button button(String title,int background,Runnable action){
        Button b=new Button(this);b.setText(title);b.setTextColor(background==Color.WHITE?INK:Color.WHITE);
        b.setTextSize(14);b.setAllCaps(false);b.setBackground(rounded(background,12));
        b.setPadding(dp(12),0,dp(12),0);b.setOnClickListener(v->action.run());return b;
    }
    private LinearLayout card(){LinearLayout l=column();pad(l,15,14);l.setBackground(rounded(Color.WHITE,16));l.setElevation(dp(2));return l;}
    private void label(LinearLayout l,String title){TextView t=text(title,14,INK,true);l.addView(t,gap(12));}
    private EditText field(LinearLayout l,String hint,String value,int inputType){
        EditText f=new EditText(this);f.setSingleLine(true);f.setTextSize(16);f.setTextColor(INK);f.setHint(hint);f.setHintTextColor(0xFF9BA9AF);
        f.setInputType(inputType);f.setText(value);f.setSelectAllOnFocus(false);f.setBackground(rounded(BG,10));
        f.setPadding(dp(12),dp(10),dp(12),dp(10));l.addView(f,gap(6));return f;
    }
    private String val(EditText f){return f==null?"":f.getText().toString().trim();}
    private void heading(LinearLayout l,String title,String desc){l.addView(text(title,21,INK,true));TextView sub=text(desc,13,MUTED,false);l.addView(sub,gap(5));}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
    private void openTab(int tab){
        this.tab=tab;
        LinearLayout root=column();root.setBackgroundColor(BG);
        LinearLayout header=column();header.setBackgroundColor(BLUE);pad(header,20,16);
        header.addView(text("商品过期 · 换货管理",23,Color.WHITE,true));
        header.addView(text("扫码登记 / 分类 / 经销商 / 换货确认",12,0xFFB7D6DC,false),gap(3));root.addView(header,lp(-1,-2));
        LinearLayout nav=row();nav.setBackgroundColor(Color.WHITE);
        String[] tabs={"＋ 登记","待分配","换货商","设置"};
        for(int i=0;i<tabs.length;i++){
            final int selected=i; TextView n=text(tabs[i],13,i==tab?TEAL:MUTED,i==tab);
            n.setGravity(Gravity.CENTER);n.setBackground(rounded(i==tab?0xFFE5F6F7:Color.WHITE,10));
            LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(50),1);p.setMargins(dp(3),dp(4),dp(3),dp(4));
            nav.addView(n,p);n.setOnClickListener(v->{editing=null;pendingPhoto="";chosen.clear();openTab(selected);});
        }root.addView(nav,lp(-1,-2));
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);
        holder=column();pad(holder,16,16);holder.setPadding(dp(16),dp(12),dp(16),dp(28));scroll.addView(holder);
        root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        page=root;setContentView(root);
        switch(tab){case 0:showEntry();break;case 1:showPending();break;case 2:showDealers();break;default:showSettings();break;}
    }
    private void showEntry(){
        heading(holder,editing!=null?"编辑商品记录":"新增过期商品","扫码优先；识别失败也可以手动登记。记录只保存在手机。 ");
        LinearLayout tools=row();LinearLayout.LayoutParams half=new LinearLayout.LayoutParams(0,dp(50),1);
        Button scan=button("▣ 扫条形码",TEAL,()->startActivityForResult(new Intent(this,ScannerActivity.class),101));
        tools.addView(scan,half);Button pic=button("◉ 拍照 / 相册",BLUE,this::choosePhoto);
        LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(0,dp(50),1);hp.leftMargin=dp(8);tools.addView(pic,hp);
        holder.addView(tools,gap(15));
        LinearLayout form=card();holder.addView(form,gap(12));
        Store.Item a=editing==null?new Store.Item():editing;
        label(form,"商品条形码");barcode=field(form,"扫码获取或手动输入",a.barcode,InputType.TYPE_CLASS_TEXT);
        Button lookup=button("查询商品信息",BLUE,()->lookup(val(barcode)));form.addView(lookup,gap(8));
        networkHint=text("优先用本地缓存和 Open Food Facts 查询",12,MUTED,false);form.addView(networkHint,gap(8));
        label(form,"商品名称 *");name=field(form,"例如 Pan lactal / Yogur",a.name,InputType.TYPE_CLASS_TEXT);
        label(form,"品牌");brand=field(form,"例如 Bimbo / La Serenísima",a.brand,InputType.TYPE_CLASS_TEXT);
        label(form,"规格");size=field(form,"例如 200g、1L、6 unidades",a.size,InputType.TYPE_CLASS_TEXT);
        label(form,"商品类别");category=new Spinner(this);
        ArrayAdapter<String> adapt=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,CATEGORIES);
        category.setAdapter(adapt);category.setSelection(categoryIndex(a.category));form.addView(category,gap(5));
        label(form,"过期数量 *");quantity=field(form,"请输入数量",String.valueOf(a.quantity),InputType.TYPE_CLASS_NUMBER);
        label(form,"过期日期（可选）");expiry=field(form,"YYYY-MM-DD",a.expiry,InputType.TYPE_CLASS_DATETIME);
        Button pickDate=button("选择日期",0xFF6C8791,this::chooseDate);form.addView(pickDate,gap(6));
        photoHint=text(pendingPhoto.isEmpty()?(a.photo.isEmpty()?"尚未添加商品照片":"已有商品照片"):"已添加商品照片",12,MUTED,false);
        form.addView(photoHint,gap(12));
        Button save=button(editing!=null?"保存修改":"登记到待分配商品池",TEAL,this::saveItem);
        holder.addView(save,gap(16));
        TextView caption=text("提示：普通条形码一般没有有效期。可以拍包装日期让 ML Kit 识别，或手工填写。",12,MUTED,false);
        holder.addView(caption,gap(10));
    }
    private int categoryIndex(String s){for(int i=0;i<CATEGORIES.length;i++)if(CATEGORIES[i].equals(s))return i;return CATEGORIES.length-1;}
    private void chooseDate(){
        Calendar c=Calendar.getInstance();Matcher m=Pattern.compile("(\\d{4})-(\\d{2})-(\\d{2})").matcher(val(expiry));
        if(m.matches()){c.set(Integer.parseInt(m.group(1)),Integer.parseInt(m.group(2))-1,Integer.parseInt(m.group(3)));}
        new DatePickerDialog(this,(view,y,mo,d)->expiry.setText(String.format(Locale.US,"%04d-%02d-%02d",y,mo+1,d)),c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH)).show();
    }
    private void saveItem(){
        String n=val(name),q=val(quantity),date=val(expiry);
        if(n.isEmpty()){name.setError("请输入商品名称");return;}
        int amount;try{amount=Integer.parseInt(q);}catch(Exception e){amount=0;}
        if(amount<=0||amount>999999){quantity.setError("数量应在 1 到 999999 之间");return;}
        if(!date.isEmpty()&&!date.matches("\\d{4}-\\d{2}-\\d{2}")){expiry.setError("请填写 YYYY-MM-DD");return;}
        Store.Item a=editing==null?new Store.Item():editing;
        a.barcode=val(barcode);a.name=n;a.brand=val(brand);a.size=val(size);a.category=category.getSelectedItem().toString();
        a.quantity=amount;a.expiry=date;
        if(!pendingPhoto.isEmpty())a.photo=pendingPhoto;
        store.save(a);store.cache(a.barcode,a.name,a.brand,a.category,a.size);
        toast(editing==null?"已保存到待分配商品池":"商品记录已更新");
        editing=null;pendingPhoto="";openTab(a.dealerId>0?2:1);
    }
    private void lookup(String code){
        if(code.isEmpty()){toast("请先输入或扫描条形码");return;}
        Store.Item cached=store.cacheGet(code);
        if(cached!=null){applyProduct(code,cached.name,cached.brand,cached.size,cached.category);networkHint.setText("已从手机本地商品库识别，可直接登记");return;}
        networkHint.setText("正在联网查询 Open Food Facts…");
        io.execute(()->{
            try {
                JSONObject p=AIClient.fetchOpenFoodFacts(code);
                runOnUiThread(()->{
                    if(tab!=0||barcode==null||!code.equals(val(barcode)))return;
                    if(p==null){networkHint.setText("数据库暂无该条码，请拍照 AI 识别或手动填写");return;}
                    String n=p.optString("product_name_es","");if(n.isEmpty())n=p.optString("product_name","");
                    String b=p.optString("brands","");String s=p.optString("quantity","");
                    String cat=classify(n+" "+b+" "+p.optString("categories","")+" "+p.optString("categories_tags",""));
                    if(n.isEmpty()) {networkHint.setText("条码已收录，但商品名称缺失，请手动填写");return;}
                    applyProduct(code,n,b,s,cat);store.cache(code,n,b,cat,s);
                    networkHint.setText("已查询到商品资料，确认后输入数量");
                });
            }catch(Exception ex){runOnUiThread(()->{if(tab==0 && networkHint!=null)networkHint.setText("查询失败，请检查网络或手动输入");});}
        });
    }
    private void applyProduct(String code,String n,String b,String s,String cat){
        if(tab!=0||barcode==null)return;
        barcode.setText(code);if(!n.isEmpty())name.setText(n);if(!b.isEmpty())brand.setText(b);
        if(!s.isEmpty())size.setText(s);category.setSelection(categoryIndex(cat));
    }
    private static String classify(String source){
        String s=source.toLowerCase(Locale.ROOT);
        if(s.matches("(?s).*(yogur|yoghurt|yogurt|酸奶|fermented milk).*"))return "酸奶";
        if(s.matches("(?s).*(panader|bread|bimbo|lactal|tostad|croissant|gallet[a-z]* de pan|面包).*"))return "面包";
        if(s.matches("(?s).*(salchich|chorizo|sausage|mortadel|fiambre|香肠).*"))return "香肠";
        if(s.matches("(?s).*(queso|cheese|leche|milk|manteca|mantequilla|乳制品|奶酪).*"))return "乳制品";
        if(s.matches("(?s).*(bebida|drink|soda|gaseosa|agua|jugo|juice|cola|饮料).*"))return "饮料";
        if(s.matches("(?s).*(helado|congelad|frozen|冷冻).*"))return "冷冻食品";
        if(s.matches("(?s).*(lata|conserva|canned|罐头).*"))return "罐头";
        if(s.matches("(?s).*(chocolate|cookie|galleta|snack|papas fritas|零食).*"))return "零食";
        if(s.matches("(?s).*(detergente|shampoo|jabón|jabon|limpiador|日用品).*"))return "日用品";
        return "其他";
    }
    private void choosePhoto(){
        new AlertDialog.Builder(this).setTitle("添加商品包装照片")
            .setItems(new String[]{"打开相机拍照","从相册选择"},(d,which)->{
                if(which==0)takePhoto();else{
                    Intent pick=new Intent(Intent.ACTION_GET_CONTENT);pick.setType("image/*");
                    try{startActivityForResult(pick,103);}catch(Exception e){toast("无法打开相册");}
                }
            }).show();
    }
    private void takePhoto(){
        try {
            File dir=new File(getFilesDir(),"photos");dir.mkdirs();
            cameraFile=File.createTempFile("photo_",".jpg",dir);
            Uri output=FileProvider.getUriForFile(this,getPackageName()+".fileprovider",cameraFile);
            Intent camera=new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            camera.putExtra(MediaStore.EXTRA_OUTPUT,output);
            camera.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION|Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivityForResult(camera,102);
        }catch(Exception e){toast("无法打开相机："+e.getMessage());}
    }
    @Override protected void onActivityResult(int request,int result,Intent data){
        super.onActivityResult(request,result,data);
        if(result!=RESULT_OK)return;
        if(request==101 && data!=null){String s=data.getStringExtra("barcode");if(s!=null && tab==0){barcode.setText(s);lookup(s);}}
        if(request==102 && cameraFile!=null && cameraFile.isFile())processPhoto(Uri.fromFile(cameraFile));
        if(request==103 && data!=null && data.getData()!=null)processPhoto(data.getData());
        if(request==104 && data!=null && data.getData()!=null)exportTo(data.getData());
        if(request==105 && data!=null && data.getData()!=null)confirmRestore(data.getData());
    }
    private Bitmap decode(Uri uri) throws Exception {
        BitmapFactory.Options check=new BitmapFactory.Options();check.inJustDecodeBounds=true;
        try(InputStream in=getContentResolver().openInputStream(uri)){BitmapFactory.decodeStream(in,null,check);}
        int sample=1;while(Math.max(check.outWidth,check.outHeight)/sample>1500)sample*=2;
        BitmapFactory.Options options=new BitmapFactory.Options();options.inSampleSize=sample;
        try(InputStream in=getContentResolver().openInputStream(uri)){
            Bitmap b=BitmapFactory.decodeStream(in,null,options);if(b==null)throw new IllegalArgumentException("无法解析照片");return b;
        }
    }
    private void processPhoto(Uri uri){
        if(tab!=0)return;
        if(photoHint!=null)photoHint.setText("正在解析图片和文字…");
        io.execute(()->{
            try {
                Bitmap b=decode(uri);
                File dir=new File(getFilesDir(),"photos");dir.mkdirs();
                File destination=File.createTempFile("saved_",".jpg",dir);
                try(FileOutputStream out=new FileOutputStream(destination)){b.compress(Bitmap.CompressFormat.JPEG,75,out);}
                pendingPhoto=destination.getAbsolutePath();
                runOnUiThread(()->{if(tab==0&&photoHint!=null)photoHint.setText("照片已保存，正在识别包装文字…");});
                com.google.mlkit.vision.text.TextRecognizer recognizer=TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
                recognizer.process(InputImage.fromBitmap(b,0))
                    .addOnSuccessListener(result->{
                        String recognized=result.getText();
                        if(tab==0){String date=detectDate(recognized);if(!date.isEmpty()&&val(expiry).isEmpty())expiry.setText(date);}
                        runOnUiThread(()->{if(tab==0 && photoHint!=null)photoHint.setText("ML Kit 已读取文字"+(recognized.isEmpty()?"（未识别到文字）":"")+"；照片已保存");});
                        callAI(b,recognized);
                    }).addOnFailureListener(ex->{runOnUiThread(()->{if(tab==0&&photoHint!=null)photoHint.setText("文字识别失败，照片已保存");});callAI(b,"");})
                    .addOnCompleteListener(task->recognizer.close());
            }catch(Exception e){runOnUiThread(()->toast("照片处理失败："+e.getMessage()));}
        });
    }
    private void callAI(Bitmap b,String ocr){
        String key=KeyVault.read(this);
        if(key.isEmpty()){
            runOnUiThread(()->{if(tab==0&&photoHint!=null)photoHint.setText("照片已保存；未设置 OpenAI Key，可手动填写或到设置开启 AI");});return;
        }
        runOnUiThread(()->{if(tab==0&&photoHint!=null)photoHint.setText("正在调用 OpenAI 智能识别（产生少量 API 费用）…");});
        io.execute(()->{
            try{
                JSONObject j=AIClient.recognize(key,b,ocr);
                runOnUiThread(()->{
                    if(tab!=0||name==null)return;
                    String n=j.optString("name","").trim(),br=j.optString("brand","").trim(),sz=j.optString("size","").trim(),cat=j.optString("category","");
                    if(!n.isEmpty())name.setText(n);if(!br.isEmpty())brand.setText(br);if(!sz.isEmpty())size.setText(sz);
                    if(!cat.isEmpty())category.setSelection(categoryIndex(cat));
                    String exp=j.optString("expiry_date","");if(exp.matches("\\d{4}-\\d{2}-\\d{2}")&&val(expiry).isEmpty())expiry.setText(exp);
                    photoHint.setText("AI 识别完成：请核对名称、品牌、日期、数量，再保存");
                });
            }catch(Exception ex){runOnUiThread(()->{if(tab==0&&photoHint!=null)photoHint.setText("OpenAI 识别未成功，请手动核对："+ex.getMessage());});}
        });
    }
    private String detectDate(String ocr){
        Pattern pattern=Pattern.compile("(?i)(?:VTO|VENC|CAD|EXP|VENCE|VENCIMIENTO|BEST BEFORE|有效期|到期)[\\s.:/-]{0,15}(\\d{1,2})[./-](\\d{1,2})[./-](\\d{2,4})");
        Matcher m=pattern.matcher(ocr);if(m.find()){
            int d=Integer.parseInt(m.group(1)),mo=Integer.parseInt(m.group(2)),y=Integer.parseInt(m.group(3));
            if(y<100)y+=2000;if(d>0&&d<=31&&mo>0&&mo<=12&&y>=2020&&y<=2100)return String.format(Locale.US,"%04d-%02d-%02d",y,mo,d);
        }
        return "";
    }
    private void showPending(){
        List<Store.Item> list=store.list(0);
        heading(holder,"待分配商品池",list.size()+" 条登记 · 自动按类别及品牌排序");
        LinearLayout actions=row();
        Button all=button("全选 / 取消",BLUE,()->{
            if(chosen.size()==list.size())chosen.clear();else{chosen.clear();for(Store.Item a:list)chosen.add(a.id);}
            openTabWithoutReset(1);
        });actions.addView(all,new LinearLayout.LayoutParams(0,dp(48),1));
        Button move=button("剪切到换货商",TEAL,this::chooseDealerForMove);
        LinearLayout.LayoutParams m=new LinearLayout.LayoutParams(0,dp(48),1);m.leftMargin=dp(7);actions.addView(move,m);
        holder.addView(actions,gap(12));
        if(list.isEmpty()){
            LinearLayout empty=card();empty.addView(text("暂无待分配商品",18,INK,true));empty.addView(text("请到「登记」页扫码或拍照添加商品。",13,MUTED,false),gap(8));holder.addView(empty,gap(14));return;
        }
        String last="";
        for(Store.Item a:list){
            String key=a.category+" → "+(a.brand.isEmpty()?"未填写品牌":a.brand);
            if(!key.equals(last)){TextView title=text(key,15,TEAL,true);holder.addView(title,gap(18));last=key;}
            holder.addView(itemCard(a,true),gap(8));
        }
    }
    private void openTabWithoutReset(int selected){
        // Used by checkboxes and selection actions; keep selection while re-rendering.
        tab=selected;openTab(selected);
    }
    private LinearLayout itemCard(Store.Item a,boolean pending){
        LinearLayout outer=card();LinearLayout top=row();
        if(pending){
            CheckBox check=new CheckBox(this);check.setChecked(chosen.contains(a.id));check.setButtonTintList(android.content.res.ColorStateList.valueOf(TEAL));
            check.setOnCheckedChangeListener((b,checked)->{if(checked)chosen.add(a.id);else chosen.remove(a.id);});
            top.addView(check,lp(44,48));
        }else{
            CheckBox done=new CheckBox(this);done.setChecked(a.exchanged==1);done.setButtonTintList(android.content.res.ColorStateList.valueOf(TEAL));
            done.setOnCheckedChangeListener((b,checked)->{store.exchanged(a.id,checked);a.exchanged=checked?1:0;toast(checked?"已记录：换货完成":"已恢复：尚未换货");});
            top.addView(done,lp(44,48));
        }
        if(a.photo!=null && !a.photo.isEmpty()){
            try{BitmapFactory.Options opt=new BitmapFactory.Options();opt.inSampleSize=5;Bitmap image=BitmapFactory.decodeFile(a.photo,opt);
                if(image!=null){ImageView pic=new ImageView(this);pic.setImageBitmap(image);pic.setScaleType(ImageView.ScaleType.CENTER_CROP);
                    LinearLayout.LayoutParams ph=lp(56,56);ph.rightMargin=dp(10);top.addView(pic,ph);}}
            catch(Exception ignored){}
        }
        LinearLayout info=column();top.addView(info,new LinearLayout.LayoutParams(0,-2,1));
        info.addView(text(a.name+"  × "+a.quantity,16,INK,true));
        info.addView(text((a.brand.isEmpty()?"未标注品牌":a.brand)+(a.size.isEmpty()?"":" · "+a.size),12,MUTED,false),gap(4));
        info.addView(text((a.barcode.isEmpty()?"":a.barcode+" · ")+(a.expiry.isEmpty()?"未填写有效期":"到期 "+a.expiry),12,MUTED,false),gap(3));
        if(!pending)info.addView(text(a.exchanged==1?"✓ 已换货":"□ 等待换货",13,a.exchanged==1?TEAL:0xFFA36A14,true),gap(4));
        outer.addView(top);
        LinearLayout actions=row();
        Button edit=button("修改",BLUE,()->{editing=a;pendingPhoto=a.photo;openTab(0);});
        LinearLayout.LayoutParams ep=new LinearLayout.LayoutParams(0,dp(39),1);actions.addView(edit,ep);
        if(!pending){
            Button back=button("撤回待分配",0xFF6B8793,()->{
                store.move(Collections.singletonList(a.id),0);toast("已撤回待分配池");openTab(2);
            });LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(39),1);p.leftMargin=dp(5);actions.addView(back,p);
        }
        Button delete=button("删除",0xFFC35C5C,()->new AlertDialog.Builder(this)
            .setTitle("删除这条商品记录？").setMessage(a.name+" × "+a.quantity+"\n删除后无法撤销。")
            .setNegativeButton("取消",null).setPositiveButton("删除",(d,w)->{store.delete(a.id);chosen.remove(a.id);openTab(pending?1:2);}).show());
        LinearLayout.LayoutParams dp2=new LinearLayout.LayoutParams(0,dp(39),1);dp2.leftMargin=dp(5);actions.addView(delete,dp2);
        outer.addView(actions,gap(10));return outer;
    }
    private void chooseDealerForMove(){
        if(chosen.isEmpty()){toast("请先勾选要移动的商品");return;}
        List<Store.Dealer> dealers=store.dealers();
        if(dealers.isEmpty()){
            new AlertDialog.Builder(this).setMessage("还没有换货商，请先去「换货商」页面创建。").setPositiveButton("知道了",null).show();return;
        }
        String[] names=new String[dealers.size()];for(int i=0;i<names.length;i++)names[i]=dealers.get(i).name;
        new AlertDialog.Builder(this).setTitle("移动 "+chosen.size()+" 条商品到哪个换货商？")
            .setItems(names,(dialog,pos)->{
                store.move(new ArrayList<>(chosen),dealers.get(pos).id);chosen.clear();
                toast("已剪切移动到："+dealers.get(pos).name);openTab(1);
            }).setNegativeButton("取消",null).show();
    }
    private void showDealers(){
        List<Store.Dealer> dealers=store.dealers();
        heading(holder,"经销商换货清单","换货成功时打勾确认，记录不会自动删除。");
        Button add=button("＋ 新增换货商",TEAL,()->dealerDialog(null));holder.addView(add,gap(14));
        if(dealers.isEmpty()){
            LinearLayout empty=card();empty.addView(text("还没有经销商",18,INK,true));
            empty.addView(text("可以手动建立面包供货商、乳制品供货商等分类。",13,MUTED,false),gap(8));holder.addView(empty,gap(14));return;
        }
        int unfinished=0;for(Store.Dealer dealer:dealers){for(Store.Item a:store.list(dealer.id))if(a.exchanged==0)unfinished++;}
        holder.addView(text("全部未完成："+unfinished+" 条   ·   已完成："+store.finishedCount()+" 条",13,MUTED,true),gap(12));
        for(Store.Dealer dealer:dealers){
            LinearLayout section=column();section.setBackground(rounded(0xFFEAF1F3,16));pad(section,10,10);
            List<Store.Item> records=store.list(dealer.id);
            LinearLayout head=row();LinearLayout details=column();details.addView(text(dealer.name,18,BLUE,true));
            int done=0;for(Store.Item a:records)if(a.exchanged==1)done++;
            details.addView(text(records.size()+" 条 · 已完成 "+done+" 条",12,MUTED,false),gap(4));
            head.addView(details,new LinearLayout.LayoutParams(0,-2,1));
            Button rename=button("改名",BLUE,()->dealerDialog(dealer));head.addView(rename,lp(67,40));
            section.addView(head);
            if(records.isEmpty()){section.addView(text("尚未分配商品，请从待分配池勾选并剪切到这里。",13,MUTED,false),gap(9));}
            String previous="";
            for(Store.Item a:records){
                String group=a.category+" / "+(a.brand.isEmpty()?"其他品牌":a.brand);
                if(!group.equals(previous)){section.addView(text(group,13,TEAL,true),gap(12));previous=group;}
                section.addView(itemCard(a,false),gap(7));
            }
            holder.addView(section,gap(14));
        }
    }
    private void dealerDialog(Store.Dealer dealer){
        EditText input=new EditText(this);input.setSingleLine(true);input.setText(dealer==null?"":dealer.name);input.setHint("例如：乳制品经销商 A");
        LinearLayout container=column();pad(container,18,4);container.addView(input);
        new AlertDialog.Builder(this).setTitle(dealer==null?"新增换货商":"修改换货商名称").setView(container)
            .setNegativeButton("取消",null).setPositiveButton("保存",(d,w)->{
                String name=input.getText().toString().trim();if(name.isEmpty()){toast("请输入换货商名称");return;}
                try{
                    if(dealer==null){if(!store.addDealer(name))toast("该换货商已经存在");}
                    else store.renameDealer(dealer.id,name);
                }catch(Exception e){toast("保存失败，检查名称是否重复");}
                openTab(2);
            }).show();
    }
    private void showSettings(){
        heading(holder,"设置与数据备份","无需 Supabase，数据保存在本机 SQLite 数据库中。 ");
        LinearLayout card=card();holder.addView(card,gap(15));
        card.addView(text("OpenAI 智能识别",17,INK,true));
        card.addView(text("不填写也能扫码、查询公开商品库、登记和换货。仅拍照 AI 识别会消耗 OpenAI API 额度。",13,MUTED,false),gap(7));
        EditText key=field(card,"填写 sk-... API Key", "",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);
        card.addView(text(KeyVault.read(this).isEmpty()?"当前未配置 Key":"已保存 Key（使用 Android Keystore 加密）",12,TEAL,false),gap(9));
        Button saveKey=button("保存 API Key",TEAL,()->{
            String candidate=val(key);
            if(candidate.isEmpty()){toast("请输入 API Key");return;}
            try{KeyVault.save(this,candidate);key.setText("");toast("密钥已加密保存到此手机");openTab(3);}catch(Exception e){toast("密钥加密失败："+e.getMessage());}
        });card.addView(saveKey,gap(12));
        Button remove=button("清除已保存 Key",0xFF8A9AA2,()->{
            new AlertDialog.Builder(this).setTitle("清除 OpenAI Key？").setNegativeButton("取消",null)
                .setPositiveButton("清除",(d,w)->{KeyVault.clear(this);openTab(3);}).show();
        });card.addView(remove,gap(8));
        LinearLayout backup=card();holder.addView(backup,gap(15));
        backup.addView(text("本地备份与恢复",17,INK,true));
        backup.addView(text("导出 JSON 文件包含商品、经销商、状态和已保存照片。更换手机或卸载前请先备份。",13,MUTED,false),gap(8));
        Button export=button("导出备份 JSON",BLUE,()->{
            Intent intent=new Intent(Intent.ACTION_CREATE_DOCUMENT);intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("application/json");intent.putExtra(Intent.EXTRA_TITLE,"ExpiredExchange_Backup_"+new SimpleDateFormat("yyyyMMdd",Locale.US).format(new java.util.Date())+".json");
            startActivityForResult(intent,104);
        });backup.addView(export,gap(12));
        Button restore=button("从备份恢复数据",0xFF6A8B95,()->{
            Intent intent=new Intent(Intent.ACTION_OPEN_DOCUMENT);intent.addCategory(Intent.CATEGORY_OPENABLE);intent.setType("application/json");
            startActivityForResult(intent,105);
        });backup.addView(restore,gap(8));
        backup.addView(text("恢复将替换当前全部商品和经销商，请先导出现有数据。",12,0xFFB2563F,false),gap(10));
        LinearLayout info=card();info.addView(text("关于 · v1.0",16,INK,true));
        info.addView(text("ML Kit 本地扫码及 OCR · Open Food Facts 商品查询 · OpenAI 可选视觉识别 · SQLite 本地持久化。",13,MUTED,false),gap(6));
        holder.addView(info,gap(15));
    }
    private void exportTo(Uri uri){
        io.execute(()->{
            try(OutputStream stream=getContentResolver().openOutputStream(uri,"w")) {
                if(stream==null)throw new Exception("无法写入文件");
                String data=store.backup().toString(2);
                stream.write(data.getBytes(java.nio.charset.StandardCharsets.UTF_8));stream.flush();
                runOnUiThread(()->toast("已导出备份，建议另存到安全位置"));
            }catch(Exception e){runOnUiThread(()->toast("备份失败："+e.getMessage()));}
        });
    }
    private void confirmRestore(Uri uri){
        new AlertDialog.Builder(this).setTitle("确认恢复数据？")
            .setMessage("此操作会清除当前记录，并用备份中的商品、换货商和换货状态替换。请确认已备份现有数据。")
            .setNegativeButton("取消",null).setPositiveButton("确认覆盖恢复",(d,w)->{
                io.execute(()->{
                    try(InputStream in=getContentResolver().openInputStream(uri)){
                        if(in==null)throw new Exception("无法读取备份文件");
                        byte[] data=Streams.readAll(in);if(data.length>50_000_000)throw new Exception("文件超过 50MB 限制");
                        store.restore(new JSONObject(new String(data,java.nio.charset.StandardCharsets.UTF_8)),this);
                        runOnUiThread(()->{toast("恢复成功");openTab(2);});
                    }catch(Exception e){runOnUiThread(()->toast("恢复失败："+e.getMessage()));}
                });
            }).show();
    }
    @Override protected void onDestroy(){super.onDestroy();io.shutdown();store.close();}
}
