package com.expiredexchange.app;

import android.graphics.Bitmap;
import android.util.Base64;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

final class AIClient {
    static JSONObject recognize(String key,Bitmap bitmap,String ocr) throws Exception {
        ByteArrayOutputStream bytes=new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG,72,bytes);
        String uri="data:image/jpeg;base64,"+Base64.encodeToString(bytes.toByteArray(),Base64.NO_WRAP);
        JSONArray content=new JSONArray();
        content.put(new JSONObject().put("type","text").put("text",
            "识别照片中的食品或日用品。只能提取看得到的内容，不能猜测。返回 JSON 对象，键必须是 name,brand,size,category,expiry_date。"+
            "category 从以下选择：面包、酸奶、香肠、乳制品、饮料、零食、冷冻食品、罐头、日用品、其他。"+
            "expiry_date 只在印有确切到期日期时填写 YYYY-MM-DD，否则空字符串。名称保留包装主要语言（可用西班牙语）。"+
            "另外检测到的 OCR 文本："+ocr));
        content.put(new JSONObject().put("type","image_url").put("image_url",new JSONObject().put("url",uri).put("detail","low")));
        JSONObject request=new JSONObject().put("model","gpt-4o-mini")
            .put("temperature",0).put("max_tokens",280)
            .put("response_format",new JSONObject().put("type","json_object"))
            .put("messages",new JSONArray().put(new JSONObject().put("role","user").put("content",content)));
        HttpURLConnection connection=(HttpURLConnection)new URL("https://api.openai.com/v1/chat/completions").openConnection();
        connection.setRequestMethod("POST");connection.setConnectTimeout(15000);connection.setReadTimeout(35000);
        connection.setRequestProperty("Authorization","Bearer "+key);
        connection.setRequestProperty("Content-Type","application/json");
        connection.setDoOutput(true);
        try {
            try(OutputStream out=connection.getOutputStream()) {out.write(request.toString().getBytes(StandardCharsets.UTF_8));}
            int status=connection.getResponseCode();
            InputStream stream=status>=200&&status<300?connection.getInputStream():connection.getErrorStream();
            if(stream==null)throw new IllegalStateException("OpenAI HTTP "+status);
            String body;
            try(InputStream in=stream){body=new String(Streams.readAll(in),StandardCharsets.UTF_8);}
            if(status<200||status>=300)throw new IllegalStateException("OpenAI HTTP "+status+": "+body.substring(0,Math.min(180,body.length())));
            JSONObject result=new JSONObject(body);
            String json=result.getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content");
            return new JSONObject(json);
        }finally{connection.disconnect();}
    }
    static JSONObject fetchOpenFoodFacts(String barcode) throws Exception {
        if(!barcode.matches("[0-9]{6,18}"))return null;
        URL url=new URL("https://world.openfoodfacts.org/api/v2/product/"+barcode+".json?fields=code,product_name,product_name_es,brands,quantity,categories,categories_tags");
        HttpURLConnection conn=(HttpURLConnection)url.openConnection();
        conn.setConnectTimeout(8500);conn.setReadTimeout(10000);conn.setRequestMethod("GET");
        conn.setRequestProperty("User-Agent","ExpiredExchange/1.0 (Android; private small-business inventory management app)");
        conn.setRequestProperty("Accept","application/json");
        try {
            if(conn.getResponseCode()!=200)return null;
            try(InputStream in=conn.getInputStream()) {
                JSONObject result=new JSONObject(new String(Streams.readAll(in),StandardCharsets.UTF_8));
                if(result.optInt("status")!=1)return null;
                return result.optJSONObject("product");
            }
        }finally{conn.disconnect();}
    }
    private AIClient(){}
}
