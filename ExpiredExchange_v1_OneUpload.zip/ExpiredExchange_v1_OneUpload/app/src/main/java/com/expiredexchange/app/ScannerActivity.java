package com.expiredexchange.app;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.TextView;
import androidx.activity.ComponentActivity;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.ImageAnalysis;
import androidx.camera.core.ImageProxy;
import androidx.camera.core.Preview;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;
import androidx.core.content.ContextCompat;
import com.google.common.util.concurrent.ListenableFuture;
import com.google.mlkit.vision.barcode.BarcodeScanning;
import com.google.mlkit.vision.barcode.BarcodeScanner;
import com.google.mlkit.vision.common.InputImage;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

public class ScannerActivity extends ComponentActivity {
    private final ExecutorService executor=Executors.newSingleThreadExecutor();
    private final AtomicBoolean busy=new AtomicBoolean(false);
    private final AtomicBoolean completed=new AtomicBoolean(false);
    private final BarcodeScanner scanner=BarcodeScanning.getClient();
    private PreviewView previewView;
    private TextView message;
    private int dp(float value){return (int)(getResources().getDisplayMetrics().density*value+.5f);}
    @Override public void onCreate(Bundle state){
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.BLACK); getWindow().setNavigationBarColor(Color.BLACK);
        FrameLayout root=new FrameLayout(this);root.setBackgroundColor(Color.BLACK);
        previewView=new PreviewView(this);root.addView(previewView,new FrameLayout.LayoutParams(-1,-1));
        TextView heading=new TextView(this);heading.setText("将条形码放入画面内\n自动扫描，无须点击拍照");heading.setGravity(Gravity.CENTER);heading.setTextColor(Color.WHITE);heading.setTextSize(19);heading.setBackgroundColor(0x99000000);
        FrameLayout.LayoutParams titleParams=new FrameLayout.LayoutParams(-1,dp(110),Gravity.TOP);root.addView(heading,titleParams);
        message=new TextView(this);message.setText("正在启动相机…");message.setGravity(Gravity.CENTER);message.setTextSize(16);message.setTextColor(Color.WHITE);message.setBackgroundColor(0x99000000);
        FrameLayout.LayoutParams bottom=new FrameLayout.LayoutParams(-1,dp(70),Gravity.BOTTOM);bottom.bottomMargin=dp(70);root.addView(message,bottom);
        Button cancel=new Button(this);cancel.setText("返回登记");cancel.setOnClickListener(v->finish());
        FrameLayout.LayoutParams bp=new FrameLayout.LayoutParams(-1,dp(64),Gravity.BOTTOM);root.addView(cancel,bp);
        setContentView(root);
        if(ContextCompat.checkSelfPermission(this,Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED)startCamera();
        else requestPermissions(new String[]{Manifest.permission.CAMERA},15);
    }
    @Override public void onRequestPermissionsResult(int request,String[] permissions,int[] grants){
        super.onRequestPermissionsResult(request,permissions,grants);
        if(request==15 && grants.length>0 && grants[0]==PackageManager.PERMISSION_GRANTED)startCamera();
        else { message.setText("相机权限未授予，可返回手动输入条形码"); }
    }
    private void startCamera(){
        ListenableFuture<ProcessCameraProvider> future=ProcessCameraProvider.getInstance(this);
        future.addListener(()->{
            if(isFinishing()||isDestroyed())return;
            try {
                ProcessCameraProvider provider=future.get();provider.unbindAll();
                Preview p=new Preview.Builder().build();p.setSurfaceProvider(previewView.getSurfaceProvider());
                ImageAnalysis analysis=new ImageAnalysis.Builder().setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build();
                analysis.setAnalyzer(executor,this::scanFrame);
                provider.bindToLifecycle(this,CameraSelector.DEFAULT_BACK_CAMERA,p,analysis);
                message.setText("识别中… 支持 EAN-13 / UPC / QR 等");
            }catch(Exception ex){message.setText("相机启动失败："+ex.getMessage());}
        },ContextCompat.getMainExecutor(this));
    }
    @androidx.camera.core.ExperimentalGetImage
    private void scanFrame(ImageProxy frame){
        if(completed.get()||!busy.compareAndSet(false,true)){frame.close();return;}
        android.media.Image media=frame.getImage();
        if(media==null){busy.set(false);frame.close();return;}
        InputImage image=InputImage.fromMediaImage(media,frame.getImageInfo().getRotationDegrees());
        scanner.process(image).addOnSuccessListener(barcodes->{
            for(com.google.mlkit.vision.barcode.common.Barcode code:barcodes){
                String raw=code.getRawValue();
                if(raw!=null&&!raw.trim().isEmpty()&&completed.compareAndSet(false,true)){
                    Intent result=new Intent();result.putExtra("barcode",raw.trim());setResult(RESULT_OK,result);finish();break;
                }
            }
        }).addOnCompleteListener(task->{busy.set(false);frame.close();});
    }
    @Override protected void onDestroy(){super.onDestroy();scanner.close();executor.shutdown();}
}
